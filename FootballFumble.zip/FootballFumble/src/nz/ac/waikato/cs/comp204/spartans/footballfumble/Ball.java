package nz.ac.waikato.cs.comp204.spartans.footballfumble;

import android.graphics.Bitmap;

public class Ball extends Sprite{
	
	// Fields for the ball...
	
	public Ball(int initX, int initY, DrawView drawView, Bitmap bitmap) {
		super(initX, initY, drawView, bitmap);
	}
	
	// Methods for the ball...
}
