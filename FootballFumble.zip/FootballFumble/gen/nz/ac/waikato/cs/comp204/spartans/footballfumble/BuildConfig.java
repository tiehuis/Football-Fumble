/** Automatically generated file. DO NOT MODIFY */
package nz.ac.waikato.cs.comp204.spartans.footballfumble;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}